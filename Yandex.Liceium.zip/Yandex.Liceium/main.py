import sys
import sqlite3
from PyQt5.QtWidgets import QApplication, QMainWindow
from Piano import Ui_MainWindow
import pyglet

class MyWidget(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pushButton.clicked.connect(self.run)
        self.pushButton_2.clicked.connect(self.run)
        self.pushButton_3.clicked.connect(self.run)
        self.pushButton_4.clicked.connect(self.run)
        self.pushButton_5.clicked.connect(self.run)
        self.pushButton_6.clicked.connect(self.run)
        self.pushButton_7.clicked.connect(self.run)
        self.pushButton_8.clicked.connect(self.run)
        self.pushButton_9.clicked.connect(self.run)
        self.pushButton_10.clicked.connect(self.run)
        self.pushButton_11.clicked.connect(self.run)
        self.pushButton_12.clicked.connect(self.run)
        self.pushButton_13.clicked.connect(self.run)
        self.pushButton_14.clicked.connect(self.run)
        self.pushButton_15.clicked.connect(self.run)
        self.pushButton_16.clicked.connect(self.run)
        self.pushButton_17.clicked.connect(self.run)
        self.pushButton_18.clicked.connect(self.run)
        self.pushButton_19.clicked.connect(self.run)
        self.pushButton_20.clicked.connect(self.run)
        self.pushButton_21.clicked.connect(self.run)
        self.pushButton_22.clicked.connect(self.run)
        self.pushButton_23.clicked.connect(self.run)
        self.pushButton_24.clicked.connect(self.run)
        self.pushButton_25.clicked.connect(self.run)
        self.pushButton_26.clicked.connect(self.run)
        self.pushButton_27.clicked.connect(self.run)
        self.pushButton_28.clicked.connect(self.run)
        self.pushButton_29.clicked.connect(self.run)
        self.pushButton_30.clicked.connect(self.run)
        self.pushButton_31.clicked.connect(self.run)
        self.pushButton_32.clicked.connect(self.run)

    def keyPressEvent(self, event):
        # нота до
        if event.key() == Qt.Key_Q:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'C3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ре бемоль
        elif event.key() == Qt.Key_A:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'D3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ре
        elif event.key() == Qt.Key_Z:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'D3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ми бемоль
        elif event.key() == Qt.Key_W:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'E3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ми
        elif event.key() == Qt.Key_S:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'E3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота фа
        elif event.key() == Qt.Key_X:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'F3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота соль бемоль
        elif event.key() == Qt.Key_E:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'G3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота соль
        elif event.key() == Qt.Key_D:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'G3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ля бемоль
        elif event.key() == Qt.Key_C:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'A3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ля
        elif event.key() == Qt.Key_R:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'A3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота си бемоль
        elif event.key() == Qt.Key_F:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'B3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота си
        elif event.key() == Qt.Key_V:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'B3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())