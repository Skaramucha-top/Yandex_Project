import sys
import sqlite3
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5 import QtCore, QtMultimedia
from Piano import Ui_MainWindow
import pyglet
import os

class MyWidget(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.load_mp3s()
        self.A3.clicked.connect(self.player[0].play)
        self.A3b.clicked.connect(self.player[1].play)
        self.A4.clicked.connect(self.player[2].play)
        self.A4b.clicked.connect(self.player[3].play)
        self.B3.clicked.connect(self.player[4].play)
        self.B3b.clicked.connect(self.player[5].play)
        self.B4.clicked.connect(self.player[6].play)
        self.B4b.clicked.connect(self.player[7].play)
        self.C3.clicked.connect(self.player[8].play)
        self.C4.clicked.connect(self.player[9].play)
        self.D3.clicked.connect(self.player[10].play)
        self.D3b.clicked.connect(self.player[11].play)
        self.D4.clicked.connect(self.player[12].play)
        self.D4b.clicked.connect(self.player[13].play)
        self.E3.clicked.connect(self.player[14].play)
        self.E3b.clicked.connect(self.player[15].play)
        self.E4.clicked.connect(self.player[16].play)
        self.E4b.clicked.connect(self.player[17].play)
        self.F3.clicked.connect(self.player[18].play)
        self.F4.clicked.connect(self.player[19].play)
        self.G3.clicked.connect(self.player[20].play)
        self.G3b.clicked.connect(self.player[21].play)
        self.G4.clicked.connect(self.player[22].play)
        self.G4b.clicked.connect(self.player[23].play)

    def load_mp3s(self):
        media = [QtCore.QUrl.fromLocalFile(i) for i in
                 [t for t in os.listdir() if '.mp3' in t]]
        media.sort()
        content = [QtMultimedia.QMediaContent(i) for i in media]
        self.player = [QtMultimedia.QMediaPlayer() for _ in content]
        for i in range(len(content)):
            self.player[i].setMedia(content[i])

    def keyPressEvent(self, event):
        # нота до
        if event.key() == Qt.Key_Q:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'C3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ре бемоль
        elif event.key() == Qt.Key_A:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'D3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ре
        elif event.key() == Qt.Key_Z:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'D3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ми бемоль
        elif event.key() == Qt.Key_W:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'E3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ми
        elif event.key() == Qt.Key_S:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'E3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота фа
        elif event.key() == Qt.Key_X:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'F3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота соль бемоль
        elif event.key() == Qt.Key_E:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'G3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота соль
        elif event.key() == Qt.Key_D:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'G3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ля бемоль
        elif event.key() == Qt.Key_C:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'A3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ля
        elif event.key() == Qt.Key_R:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'A3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота си бемоль
        elif event.key() == Qt.Key_F:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'B3 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота си
        elif event.key() == Qt.Key_V:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'B3'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота до
        if event.key() == Qt.Key_T:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'C4'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ре бемоль
        elif event.key() == Qt.Key_G:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'D4 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ре
        elif event.key() == Qt.Key_B:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'D4'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ми бемоль
        elif event.key() == Qt.Key_Y:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'E4 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ми
        elif event.key() == Qt.Key_H:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'E4'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота фа
        elif event.key() == Qt.Key_N:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'F4'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота соль бемоль
        elif event.key() == Qt.Key_U:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'G4 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота соль
        elif event.key() == Qt.Key_J:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'G4'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ля бемоль
        elif event.key() == Qt.Key_M:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'A4 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота ля
        elif event.key() == Qt.Key_I:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'A4'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота си бемоль
        elif event.key() == Qt.Key_K:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'B4 b'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()
        # нота си
        elif event.key() == Qt.Key_O:
            con = sqlite3.connect('data_sounds.db')
            cur = con.cursor()
            result = cur.execute("""SELECT Адрес FROM Sounds WHERE name = 'B4'""").fetchall()
            for i in result:
                mus = pyglet.resource.media("{}".format(*i))
                mus.play()
                pyglet.app.run()
            con.close()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())